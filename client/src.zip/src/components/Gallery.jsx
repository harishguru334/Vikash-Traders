import { useState } from 'react';

const galleryPhotos = [
  {
    src: '/photos/fiable-hero-equipment.jpg',
    category: 'Equipment',
    title: 'Commercial Sanitation Lineup',
    caption: 'Pedal bins, heavy wheeled dustbins, and mechanized scrubbers staged for institutional delivery.',
  },
  {
    src: '/photos/about-facility-stockyard.jpg',
    category: 'Stockyard',
    title: 'Central Stockyard Facility',
    caption: 'Warehouse logistics base in Lunkaransar storing ready inventory for rapid dispatch.',
  },
  {
    src: '/photos/why-yellow-bin.jpg',
    category: 'Bins',
    title: 'Heavy-Duty UV Stabilized Bins',
    caption: 'Virgin HDPE commercial bins designed for extreme climate resistance and public durability.',
  },
  {
    src: '/photos/open-gym-park.svg',
    category: 'Gym',
    title: 'Public Park Fitness Stations',
    caption: 'Outdoor gym air walkers and waist twisters installed in civic park facilities.',
  },
  {
    src: '/photos/concrete-mixer-dispatch.svg',
    category: 'Construction',
    title: 'Civil Construction Machinery',
    caption: 'Portable and semi-automatic concrete mixers ready for road and construction transport.',
  },
  {
    src: '/photos/ride-on-scrubber.svg',
    category: 'Equipment',
    title: 'Industrial Floor Cleaning Fleet',
    caption: 'Mechanized scrubbers and wet & dry vacuums for corporate and hospital maintenance.',
  },
];

const categories = ['All', 'Stockyard', 'Equipment', 'Bins', 'Gym', 'Construction'];

export default function Gallery() {
  const [activeTab, setActiveTab] = useState('All');

  const filtered = activeTab === 'All'
    ? galleryPhotos
    : galleryPhotos.filter((p) => p.category === activeTab);

  return (
    <section className="section gallery-section" id="gallery" aria-label="Visual Stockyard & Operations Gallery">
      <div className="shell">
        <span className="section-eyebrow">&mdash; VERIFIED OPERATIONS &mdash;</span>
        <div className="section-head reveal">
          <h2>Stockyard Inventory &amp; <em>Dispatched Equipment</em></h2>
          <p>
            Real visuals from our central stockyard in Lunkaransar and operational machinery deployed across Rajasthan.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="gallery-tabs reveal" role="tablist" aria-label="Gallery Filters">
          {categories.map((cat) => (
            <button
              key={cat}
              className={'gallery-tab' + (activeTab === cat ? ' gallery-tab--active' : '')}
              onClick={() => setActiveTab(cat)}
              role="tab"
              aria-selected={activeTab === cat}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="gallery-grid reveal">
          {filtered.map((item, idx) => (
            <article className="gallery-card" key={idx}>
              <div className="gallery-card__img-wrap">
                <img
                  src={item.src}
                  alt={item.title}
                  loading="lazy"
                  className="gallery-card__img"
                />
                <span className="gallery-card__badge">{item.category}</span>
              </div>
              <div className="gallery-card__body">
                <h3 className="gallery-card__title">{item.title}</h3>
                <p className="gallery-card__caption">{item.caption}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
