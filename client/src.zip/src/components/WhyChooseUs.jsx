import { BUSINESS } from '../site.js';

export default function WhyChooseUs() {
  const pillars = [
    {
      title: 'Premium Industrial Build',
      desc: 'High-grade virgin polymers, heavy-duty bearings, and robust steel alloys engineered for maximum service longevity.',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <polyline points="9 12 11 14 15 10"/>
        </svg>
      )
    },
    {
      title: 'Desert Climate Durability',
      desc: 'Engineered specifically for extreme weather: high summer heat, wind-borne desert dust, and intensive civic usage.',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <circle cx="12" cy="12" r="5"/>
          <line x1="12" y1="1" x2="12" y2="3"/>
          <line x1="12" y1="21" x2="12" y2="23"/>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
          <line x1="1" y1="12" x2="3" y2="12"/>
          <line x1="21" y1="12" x2="23" y2="12"/>
        </svg>
      )
    },
    {
      title: 'Eco-Friendly & EN-840 Norms',
      desc: '100% recyclable virgin HDPE bins and energy-efficient commercial sanitation solutions matching national municipal norms.',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/>
          <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>
        </svg>
      )
    },
    {
      title: 'GST Verified & Direct Stockyard',
      desc: `GSTIN: ${BUSINESS.gst} verified commercial firm. Direct freight dispatch from central stockyard with official tax invoices.`,
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
          <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
        </svg>
      )
    }
  ];

  return (
    <section className="section why-section" id="why" aria-label="Why Choose Vikash Traders">
      <div className="shell reveal">
        <span className="section-eyebrow">&mdash; COMMERCIAL ADVANTAGES &mdash;</span>
        <div className="section-head">
          <h2>Why Procurement Teams Choose <em>Vikash Traders</em></h2>
          <p>
            Durable, certified, and cost-effective commercial equipment solutions trusted by contractors,
            infrastructure developers, and municipal institutions across Rajasthan.
          </p>
        </div>

        {/* 4-Pillar Grid */}
        <div className="why-grid">
          {pillars.map((p, idx) => (
            <div key={idx} className="why-card">
              <div className="why-card__icon">{p.icon}</div>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
            </div>
          ))}
        </div>

        {/* Bottom Credential Strip */}
        <div className="why-banner">
          <div style={{ flexShrink: 0, width: 44, height: 44, borderRadius: 8, background: '#0c5e42', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <polyline points="9 12 11 14 15 10"/>
            </svg>
          </div>
          <div>
            <strong>Verified Direct Procurement Partner</strong>
            <p>
              Holding physical inventory in our central Lunkaransar stockyard enables same-day dispatch and zero speculative middle-tier markups.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
