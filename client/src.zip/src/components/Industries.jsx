const industries = [
  {
    title: 'Municipal Corporations & Civic Bodies',
    badge: 'Civic Hygiene',
    icon: 'building',
    body: 'Sanitation departments buying commercial bins, street sweepers and scrubbers in volume with verified tender paperwork.',
  },
  {
    title: 'Construction Sites & Civil Projects',
    badge: 'Heavy Duty',
    icon: 'construction',
    body: 'Contractors sourcing semi-automatic concrete mixers, compressive test hammers and queue stanchions for active sites.',
  },
  {
    title: 'Hospitals & Medical Facilities',
    badge: 'Sanitation',
    icon: 'hospital',
    body: 'Healthcare institutions requiring colour-coded biomedical waste bins, wet & dry vacuums and automatic shoe polishers.',
  },
  {
    title: 'Public Parks & Sports Grounds',
    badge: 'Civic Amenity',
    icon: 'park',
    body: 'Gram panchayats and municipal councils installing outdoor open-gym air walkers, waist twisters and robust public park equipment.',
  },
  {
    title: 'Commercial Complexes & Malls',
    badge: 'Facility Care',
    icon: 'mall',
    body: 'Property managers deploying floor scrubber driers, entrance queue stands, and automatic shoe shiners for daily operations.',
  },
  {
    title: 'Educational Institutions & Campuses',
    badge: 'Campus Care',
    icon: 'education',
    body: 'Colleges and residential schools ordering high-capacity open-top dustbins, campus sweepers and outdoor fitness stations.',
  },
];

function IndustryIcon({ type }) {
  if (type === 'building') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="4" y="2" width="16" height="20" rx="2"/>
        <line x1="9" y1="22" x2="9" y2="2"/>
        <line x1="8" y1="6" x2="8.01" y2="6"/>
        <line x1="16" y1="6" x2="16.01" y2="6"/>
        <line x1="8" y1="11" x2="8.01" y2="11"/>
        <line x1="16" y1="11" x2="16.01" y2="11"/>
      </svg>
    );
  }
  if (type === 'construction') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="12 2 2 7 12 12 22 7 12 2"/>
        <polyline points="2 17 12 22 22 17"/>
        <polyline points="2 12 12 17 22 12"/>
      </svg>
    );
  }
  if (type === 'hospital') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 6v12M6 12h12"/>
        <rect x="3" y="3" width="18" height="18" rx="4"/>
      </svg>
    );
  }
  if (type === 'park') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22v-7"/>
        <path d="M17 15c1.66 0 3-1.34 3-3 0-1.3-.84-2.4-2-2.82V9a5 5 0 0 0-10 0v.18C6.84 9.6 6 10.7 6 12c0 1.66 1.34 3 3 3"/>
      </svg>
    );
  }
  if (type === 'mall') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
        <line x1="3" y1="6" x2="21" y2="6"/>
        <path d="M16 10a4 4 0 0 1-8 0"/>
      </svg>
    );
  }
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
      <path d="M6 12v5c3 3 9 3 12 0v-5"/>
    </svg>
  );
}

export default function Industries() {
  return (
    <section className="section" id="industries" aria-label="Industries We Serve">
      <div className="shell">
        <span className="section-eyebrow">&mdash; SECTORS WE SUPPLY &mdash;</span>
        <div className="section-head reveal">
          <h2>Serving Key Sectors Across <em>Rajasthan</em></h2>
          <p>
            From municipal public hygiene tenders to corporate facility maintenance and civil infrastructure,
            our inventory supports diverse institutional procurement needs.
          </p>
        </div>

        <div className="industries reveal">
          {industries.map((ind) => (
            <article className="ind-card" key={ind.title}>
              <div className="ind-card__header">
                <div className="ind-card__icon-box">
                  <IndustryIcon type={ind.icon} />
                </div>
                <span className="ind-card__badge">{ind.badge}</span>
              </div>
              <h3 className="ind-card__title">{ind.title}</h3>
              <p className="ind-card__body">{ind.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
