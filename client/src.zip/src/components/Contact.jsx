import { useEffect, useState } from 'react';
import api, { apiError } from '../api/client.js';
import { BUSINESS, WHATSAPP_LINK } from '../site.js';
import { IconWhatsApp } from './Icons.jsx';

const EMPTY = { name: '', phone: '', product: '', message: '' };

export default function Contact({ products = [], presetProduct, onPresetUsed }) {
  const [form, setForm] = useState(EMPTY);
  const [status, setStatus] = useState({ state: 'idle', message: '' });

  useEffect(() => {
    if (presetProduct) {
      setForm((prev) => ({ ...prev, product: presetProduct }));
      onPresetUsed?.();
    }
  }, [presetProduct, onPresetUsed]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      setStatus({ state: 'error', message: 'Please enter your name and contact phone number.' });
      return;
    }
    setStatus({ state: 'busy', message: 'Sending your quote request...' });
    try {
      await api.post('/enquiries', form);
      setStatus({
        state: 'success',
        message: 'Thank you! Your quote request has been received. Our team will contact you shortly.',
      });
      setForm(EMPTY);
    } catch (err) {
      setStatus({ state: 'error', message: apiError(err, 'Failed to send request. Please call or WhatsApp us directly.') });
    }
  };

  return (
    <section className="section contact-section" id="contact" aria-label="Contact Vikash Traders">
      <div className="shell">
        <span className="section-eyebrow">&mdash; GET IN TOUCH &mdash;</span>
        <div className="section-head reveal">
          <h2>Request a Formal Quotation or <em>Visit Our Stockyard</em></h2>
          <p>
            Whether you need a single piece or bulk municipal supply, fill in your requirements below for same-day rates.
          </p>
        </div>

        <div className="contact-grid reveal">
          {/* Left Column: Form */}
          <div className="contact-card">
            <h3 className="contact-card__title">Request Equipment Quotation</h3>
            <p className="contact-card__desc">Fill in your requirements and we will send an itemized GST rate sheet.</p>

            <form onSubmit={handleSubmit} className="contact-form" noValidate>
              <div className="form-group">
                <label htmlFor="contact-name">Full Name or Organisation *</label>
                <input
                  id="contact-name"
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="e.g. R. K. Sharma (Sharma Construction)"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="contact-phone">Phone / WhatsApp Number *</label>
                <input
                  id="contact-phone"
                  type="tel"
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  placeholder="e.g. 98290 XXXXX"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="contact-product">Equipment of Interest</label>
                <select
                  id="contact-product"
                  name="product"
                  value={form.product}
                  onChange={handleChange}
                >
                  <option value="">Select equipment or general enquiry...</option>
                  {products.map((p) => (
                    <option key={p._id} value={p.name}>
                      {p.name} ({p.category})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="contact-message">Requirements &amp; Quantity Needed</label>
                <textarea
                  id="contact-message"
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  rows="4"
                  placeholder="State quantity, required delivery location in Rajasthan, and any technical specifications..."
                />
              </div>

              {status.message && (
                <div className={'form-status form-status--' + status.state}>
                  {status.message}
                </div>
              )}

              <button
                type="submit"
                className="btn btn--primary btn--full"
                disabled={status.state === 'busy'}
              >
                {status.state === 'busy' ? 'Submitting Request...' : 'Submit Quote Request →'}
              </button>
            </form>
          </div>

          {/* Right Column: Business Information */}
          <div className="contact-info-card">
            <h3 className="contact-card__title">Direct Contact &amp; Facility Details</h3>
            <p className="contact-card__desc">Verified business information from our registered statutory profile.</p>

            <div className="contact-info-list">
              <div className="contact-info-item">
                <div className="contact-info-item__icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                  </svg>
                </div>
                <div>
                  <strong>Phone Support</strong>
                  <p>
                    <a href={'tel:' + BUSINESS.phoneDial}>{BUSINESS.phone}</a>
                  </p>
                </div>
              </div>

              <div className="contact-info-item">
                <div className="contact-info-item__icon">
                  <IconWhatsApp width="20" height="20" />
                </div>
                <div>
                  <strong>Direct WhatsApp</strong>
                  <p>
                    <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer">
                      Message directly on WhatsApp &rarr;
                    </a>
                  </p>
                </div>
              </div>

              <div className="contact-info-item">
                <div className="contact-info-item__icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                    <circle cx="12" cy="10" r="3"/>
                  </svg>
                </div>
                <div>
                  <strong>Operating Stockyard Base</strong>
                  <p>{BUSINESS.address}</p>
                </div>
              </div>

              <div className="contact-info-item">
                <div className="contact-info-item__icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                  </svg>
                </div>
                <div>
                  <strong>Working Hours</strong>
                  <p>{BUSINESS.hours}</p>
                </div>
              </div>

              <div className="contact-info-item">
                <div className="contact-info-item__icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    <polyline points="9 12 11 14 15 10"/>
                  </svg>
                </div>
                <div>
                  <strong>GSTIN &amp; Firm Entity</strong>
                  <p>{BUSINESS.name} &middot; GSTIN: {BUSINESS.gst}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
