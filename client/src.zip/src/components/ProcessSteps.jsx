const steps = [
  {
    n: '01',
    tag: 'Step 01 · Inquiry',
    title: 'Submit Your Requirement',
    body: 'Reach out by phone, WhatsApp, or through the online enquiry form. Specify the product model, quantity required, and your delivery pin code or town.',
  },
  {
    n: '02',
    tag: 'Step 02 · Quotation',
    title: 'Receive Written Quote',
    body: 'Receive a formal written quotation with per-piece unit rates, applicable GST, transport freight estimate, and expected delivery timeline the same working day.',
  },
  {
    n: '03',
    tag: 'Step 03 · Dispatch',
    title: 'Order Approval & Invoicing',
    body: 'Upon quote approval, we generate the compliant GST tax invoice, verify consignee details, and load the order at our Kankarwala stockyard.',
  },
  {
    n: '04',
    tag: 'Step 04 · Handover',
    title: 'Site Delivery & Demonstration',
    body: 'Consignment arrives safely at your site across Rajasthan. Machine demonstration and operational guidance provided for floor scrubbers and sweepers.',
  },
];

export default function ProcessSteps() {
  return (
    <section className="section" id="process" aria-label="How an Order Works">
      <div className="shell reveal">
        <span className="section-eyebrow">Procurement Workflow</span>
        <div className="section-head">
          <h2>Clear &amp; Direct 4-Step Order Process</h2>
          <p>
            No unnecessary intermediaries or delays: a streamlined procurement sequence from initial inquiry
            to verified site delivery.
          </p>
        </div>

        <div className="steps">
          {steps.map((s) => (
            <div className="step" key={s.n}>
              <div className="step__header">
                <div className="step__n" aria-label={`Step number ${s.n}`}>
                  {s.n}
                </div>
                <span className="step__tag">{s.tag}</span>
              </div>
              <h3>{s.title}</h3>
              <p>{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
