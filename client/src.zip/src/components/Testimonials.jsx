import { BUSINESS } from '../site.js';

const commitments = [
  {
    title: '100% Tax Compliant Documentation',
    desc: 'Every dispatch is accompanied by an itemized GST tax invoice (GSTIN: ' + BUSINESS.gst + ') and transport challan, ensuring smooth institutional audit clearance.',
  },
  {
    title: 'Accurate Specifications & Handover',
    desc: 'What you order is what is dispatched: verified liter capacities for bins, gauge thickness for outdoor gym steel, and tested electric motors for machines.',
  },
  {
    title: 'Direct Stockyard Transparency',
    desc: 'We operate from our dedicated warehouse in Lunkaransar, Bikaner division. No speculative broker chains or surprise lead times.',
  },
];

export default function Testimonials() {
  return (
    <section className="section testimonials-section band-paper" id="testimonials" aria-label="Procurement Assurance">
      <div className="shell">
        <div className="section-head reveal">
          <span className="section-eyebrow">&mdash; PROCUREMENT INTEGRITY &mdash;</span>
          <h2>The Vikash Traders <em>Supply Assurance</em></h2>
          <p>
            Institutional buyers, civil contractors and facility managers choose us for straightforward dealings,
            transparent rates, and complete statutory integrity.
          </p>
        </div>

        <div className="testimonials-grid reveal">
          {commitments.map((c, idx) => (
            <div className="assurance-card" key={idx}>
              <div className="assurance-card__icon-box">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                  <polyline points="9 12 11 14 15 10"/>
                </svg>
              </div>
              <h3 className="assurance-card__title">{c.title}</h3>
              <p className="assurance-card__desc">{c.desc}</p>
            </div>
          ))}
        </div>

        <div className="assurance-footer reveal">
          <div className="assurance-footer__item">
            <strong>Active GSTIN</strong>
            <span>{BUSINESS.gst}</span>
          </div>
          <div className="assurance-footer__divider">/</div>
          <div className="assurance-footer__item">
            <strong>Operating Facility</strong>
            <span>Lunkaransar, Bikaner Division</span>
          </div>
          <div className="assurance-footer__divider">/</div>
          <div className="assurance-footer__item">
            <strong>Customer Service</strong>
            <span>{BUSINESS.phone}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
