import { BUSINESS } from '../site.js';
import { IconCertificate, IconUser, IconTruck, IconClock } from './Icons.jsx';

const items = [
  {
    Icon: IconCertificate,
    title: 'GST Registered Invoicing',
    note: `Tax invoice (GSTIN ${BUSINESS.gst}) compliant for audits and institutional tenders`,
  },
  {
    Icon: IconUser,
    title: 'Direct Owner Accountability',
    note: `Speak directly with proprietor ${BUSINESS.proprietor} — no intermediaries or call centres`,
  },
  {
    Icon: IconTruck,
    title: 'Statewide Transport Dispatch',
    note: 'Fast delivery from Lunkaransar stockyard to municipal wards and project sites',
  },
  {
    Icon: IconClock,
    title: 'Same-Day Written Quotes',
    note: 'Inquiries before 7 PM received itemized rates and freight estimates the same day',
  },
];

export default function TrustStrip() {
  return (
    <section className="trust" aria-label="Verified Business Credentials">
      <div className="shell">
        <div className="trust__grid">
          {items.map(({ Icon, title, note }) => (
            <div className="trust__item" key={title}>
              <div className="trust__icon-wrap" aria-hidden="true">
                <Icon width="22" height="22" />
              </div>
              <div>
                <strong>{title}</strong>
                <span>{note}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
