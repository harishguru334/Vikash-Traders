import { WHATSAPP_LINK } from '../site.js';
import { IconWhatsApp } from './Icons.jsx';

export default function WhatsAppFloat() {
  return (
    <div className="wa-float-wrap">
      <div className="wa-float-pulse" aria-hidden="true" />
      <a
        className="wa-float-btn group"
        href={WHATSAPP_LINK}
        target="_blank"
        rel="noreferrer"
        aria-label="Message Vikash Traders on WhatsApp"
      >
        <span className="transform group-hover:scale-115 transition-transform duration-200">
          <IconWhatsApp aria-hidden="true" width="30" height="30" />
        </span>
      </a>
    </div>
  );
}
