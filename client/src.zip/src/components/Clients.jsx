const sectors = [
  {
    name: 'Municipal Corporations',
    tag: 'CIVIC SANITATION',
    desc: 'Nagar Palikas & Urban Local Bodies procuring commercial dustbins, street sweepers and tender documentation.',
  },
  {
    name: 'Infrastructure & PWD Sites',
    tag: 'CIVIL WORKS',
    desc: 'Contractors sourcing semi-automatic concrete mixers, test hammers, and site perimeter queue stanchions.',
  },
  {
    name: 'Gram Panchayats & Parks',
    tag: 'PUBLIC FITNESS',
    desc: 'Rural development and municipal councils setting up community open-gym exercise stations.',
  },
  {
    name: 'Hospitals & Healthcare Units',
    tag: 'HEALTH HYGIENE',
    desc: 'Medical centres maintaining hygiene with pedal bins, scrubber driers and sensory automatic shoe shiners.',
  },
  {
    name: 'Commercial & Facility Hubs',
    tag: 'FACILITY MANAGEMENT',
    desc: 'Hotels, colleges and malls requiring ongoing dispatch of cleaning machinery and waste stations.',
  },
];

export default function Clients() {
  return (
    <section className="section clients-section band-paper" id="clients" aria-label="Sectors &amp; Client Networks">
      <div className="shell">
        <div className="section-head reveal">
          <span className="section-eyebrow">&mdash; INSTITUTIONAL TRUST &mdash;</span>
          <h2>Procurement Networks &amp; <em>Sectors Served</em></h2>
          <p>
            Direct equipment supplies with full GST tax invoice compliance to public works, civic bodies,
            and commercial projects across Rajasthan.
          </p>
        </div>

        {/* Animated Marquee Ticker */}
        <div className="marquee-container my-8 py-3 bg-white/70 backdrop-blur-sm rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="marquee-content">
            {sectors.concat(sectors).map((sec, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 px-5 py-2.5 bg-slate-50 hover:bg-emerald-50 rounded-full border border-slate-200 hover:border-emerald-300 transition-all duration-200 whitespace-nowrap shadow-xs"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700">{sec.tag}</span>
                <span className="text-xs font-bold text-slate-800">{sec.name}</span>
              </div>
            ))}
          </div>
          <div className="marquee-content" aria-hidden="true">
            {sectors.concat(sectors).map((sec, idx) => (
              <div
                key={'dup-' + idx}
                className="flex items-center gap-3 px-5 py-2.5 bg-slate-50 hover:bg-emerald-50 rounded-full border border-slate-200 hover:border-emerald-300 transition-all duration-200 whitespace-nowrap shadow-xs"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700">{sec.tag}</span>
                <span className="text-xs font-bold text-slate-800">{sec.name}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="sectors-grid reveal mt-6">
          {sectors.map((sec) => (
            <div className="sector-card group" key={sec.name}>
              <span className="sector-card__tag group-hover:text-emerald-700 transition-colors">{sec.tag}</span>
              <h3 className="sector-card__name group-hover:text-emerald-800 transition-colors">{sec.name}</h3>
              <p className="sector-card__desc">{sec.desc}</p>
            </div>
          ))}
        </div>

        <div className="clients-dispatch-strip reveal mt-8">
          <div className="clients-dispatch-strip__dot" aria-hidden="true" />
          <span>Central Stockyard in Lunkaransar (Bikaner division) with direct road transport dispatch.</span>
        </div>
      </div>
    </section>
  );
}
