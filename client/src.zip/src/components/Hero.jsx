import { BUSINESS } from '../site.js';

function Stat({ value, suffix = '', label, sub }) {
  return (
    <div className="stat">
      <div className="stat__value">
        {value}
        {suffix}
      </div>
      <div className="stat__label">{label}</div>
      <div className="stat__sub">{sub}</div>
    </div>
  );
}

export default function Hero({ products = [] }) {
  const categoryCount = new Set(products.map((p) => p.category)).size;

  return (
    <section className="fiable-hero" id="top" aria-label="Vikash Traders Equipment Procurement">
      <div className="shell">
        <div className="fiable-hero__grid">
          {/* Left Column: Authoritative Editorial Copy & CTAs */}
          <div className="fiable-hero__content">
            <div className="fiable-hero__badge">
              <span className="fiable-hero__badge-dot" aria-hidden="true" />
              DIRECT B2B INDUSTRIAL SOURCING &middot; RAJASTHAN
            </div>

            <h1 className="fiable-hero__title">
              Commercial &amp; Municipal Equipment <em>Directly from the Stockyard</em>
            </h1>

            <p className="fiable-hero__lead">
              Government and commercial-grade supplier of heavy-duty cleaning machines, HDPE waste containers,
              institutional outdoor gym stations, and construction equipment with official GST tax invoicing.
            </p>

            <div className="fiable-hero__actions">
              <a className="btn btn--primary" href="#products">
                Explore Catalogue &amp; Rates &rarr;
              </a>

              <a className="btn btn--ghost" href="#contact">
                Request Official Quotation
              </a>
            </div>

            <div className="fiable-hero__perks">
              <span className="fiable-hero__perk">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#0c5e42" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                100% Tax Invoices with GSTIN
              </span>
              <span className="fiable-hero__perk">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#0c5e42" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                Lunkaransar Stockyard Hub
              </span>
              <span className="fiable-hero__perk">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#0c5e42" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                Pan-Rajasthan Road Freight
              </span>
            </div>
          </div>

          {/* Right Column: Clean Architectural Showcase Container */}
          <div className="fiable-hero__stage">
            <div className="fiable-hero__showcase">
              <img
                src="/photos/fiable-hero-equipment.jpg"
                alt="Vikash Traders Commercial Equipment Showcase"
                className="fiable-hero__showcase-img"
              />
              <div style={{ padding: '14px 18px', background: '#ffffff', borderTop: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <strong style={{ display: 'block', fontSize: '0.85rem', color: '#0f172a' }}>Lunkaransar Central Facility</strong>
                  <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Ready for Dispatch &middot; Verified In-Stock</span>
                </div>
                <span style={{ fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', background: '#ecfdf5', color: '#065f46', padding: '4px 8px', borderRadius: 4, border: '1px solid #a7f3d0' }}>
                  GSTIN: {BUSINESS.gst}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Four Business Metric Cards */}
        <div className="fiable-stats-strip" aria-label="Business Metrics">
          <Stat
            value={BUSINESS.gstYear}
            label="GST Registered Since"
            sub="Proprietor V. Kumar"
          />
          <Stat
            value={products.length || 20}
            suffix="+"
            label="Catalogue Models"
            sub="Ready in stockyard"
          />
          <Stat
            value={categoryCount || 8}
            label="Equipment Categories"
            sub="Gym, Bins, Cleaners &amp; Mixers"
          />
          <Stat
            value="Bikaner Hub"
            label="Central Stockyard"
            sub="Direct road freight dispatch"
          />
        </div>
      </div>
    </section>
  );
}
