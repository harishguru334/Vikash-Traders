import { useEffect, useState, useRef } from 'react';
import { BUSINESS } from '../site.js';

const PRODUCT_FAMILIES = [
  {
    name: 'Plastic Dust Bins',
    desc: '5L to 100L open-top, pedal & wheeled heavy bins',
    icon: '/icons/cat-dustbins.svg',
    target: 'Plastic Dust Bins',
  },
  {
    name: 'Cleaning Machines',
    desc: 'Scrubber driers, sweepers & wet/dry vacuums',
    icon: '/icons/cat-cleaning.svg',
    target: 'Cleaning Machines',
  },
  {
    name: 'Outdoor Gym Equipment',
    desc: 'Waist twisters, air walkers & park stations',
    icon: '/icons/cat-gym.svg',
    target: 'Outdoor Exercise Gym Equipment',
  },
  {
    name: 'Queue Stands',
    desc: 'Stainless steel stanchions with retractable belts',
    icon: '/icons/cat-queuestands.svg',
    target: 'Queue Stands',
  },
  {
    name: 'Concrete Mixer Machines',
    desc: 'Portable & semi-automatic construction mixers',
    icon: '/icons/cat-concretemixer.svg',
    target: 'Concrete Mixer Machines',
  },
  {
    name: 'Concrete Test Hammer',
    desc: 'Schmidt rebound hammer for compressive strength',
    icon: '/icons/cat-testhammer.svg',
    target: 'Concrete Test Hammer',
  },
  {
    name: 'Shoe Polish Machine',
    desc: 'Dual-buffer sensor automatic commercial shiner',
    icon: '/icons/cat-shoepolish.svg',
    target: 'Shoe Polish Machine',
  },
  {
    name: 'Scrubbing & Polishing Machine',
    desc: 'Single-disc heavy floor scrubber & polisher',
    icon: '/icons/cat-scrubber.svg',
    target: 'Scrubbing & Polishing Machine',
  },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);

  const productsRef = useRef(null);
  const aboutRef = useRef(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setOpen(false);
        setProductsOpen(false);
        setAboutOpen(false);
      }
    };
    const onClickOutside = (e) => {
      if (productsRef.current && !productsRef.current.contains(e.target)) {
        setProductsOpen(false);
      }
      if (aboutRef.current && !aboutRef.current.contains(e.target)) {
        setAboutOpen(false);
      }
    };
    window.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onClickOutside);
    return () => {
      window.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onClickOutside);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  const closeAll = () => {
    setOpen(false);
    setProductsOpen(false);
    setAboutOpen(false);
  };

  return (
    <>
      {/* Floating Agency Header Pill */}
      <div className={'fiable-header-wrapper' + (scrolled ? ' is-scrolled' : '')}>
        <header className="fiable-header">
          <div className="fiable-header__inner">
            {/* Logo */}
            <a className="fiable-logo" href="#top" onClick={closeAll} aria-label="Vikash Traders Homepage">
              <span className="fiable-logo__mark" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L3 7v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-9-5z" fill="#047857"/>
                  <path d="M12 6l-5 3v3.5c0 3.3 2.1 6.3 5 7.2 2.9-.9 5-3.9 5-7.2V9l-5-3z" fill="#10b981"/>
                  <path d="M9.5 12l2 2 3.5-3.5" stroke="#ffffff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </span>
              <span className="fiable-logo__text">
                <span className="fiable-logo__brand">
                  vikash <span className="fiable-logo__brand-sub">Traders</span>
                </span>
                <span className="fiable-logo__tagline">CIVIC &amp; COMMERCIAL EQUIPMENT</span>
              </span>
            </a>

            {/* Desktop Navigation */}
            <nav className="fiable-nav" aria-label="Main Navigation">
              <a className="fiable-nav__link" href="#top" onClick={closeAll}>
                Home
              </a>

              {/* About Dropdown */}
              <div
                className={'fiable-nav__item-dropdown' + (aboutOpen ? ' is-active' : '')}
                ref={aboutRef}
                onMouseEnter={() => setAboutOpen(true)}
                onMouseLeave={() => setAboutOpen(false)}
              >
                <a
                  className={'fiable-nav__link' + (aboutOpen ? ' is-open' : '')}
                  href="#about"
                  onClick={(e) => {
                    if (window.innerWidth < 1024) {
                      e.preventDefault();
                      setAboutOpen(!aboutOpen);
                    }
                  }}
                  aria-expanded={aboutOpen}
                  aria-haspopup="true"
                >
                  About Us
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={'fiable-nav__chevron' + (aboutOpen ? ' is-up' : '')}>
                    <path d="m6 9 6 6 6-6"/>
                  </svg>
                </a>

                <div className="about-dropdown" role="menu">
                  <a className="about-dropdown__item" href="#about" onClick={closeAll}>
                    <div className="about-dropdown__icon">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                      </svg>
                    </div>
                    <div>
                      <strong>Company Overview</strong>
                      <p>Our foundation, stockyard infrastructure &amp; capabilities since {BUSINESS.gstYear}.</p>
                    </div>
                  </a>
                  <a className="about-dropdown__item" href="#certifications" onClick={closeAll}>
                    <div className="about-dropdown__icon">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="8" r="7"/>
                        <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>
                      </svg>
                    </div>
                    <div>
                      <strong>Certifications &amp; Standards</strong>
                      <p>GSTIN: {BUSINESS.gst} · ISO &amp; EN-840 compliance standards.</p>
                    </div>
                  </a>
                </div>
              </div>

              {/* Products Mega Menu */}
              <div
                className={'fiable-nav__item-dropdown' + (productsOpen ? ' is-active' : '')}
                ref={productsRef}
                onMouseEnter={() => setProductsOpen(true)}
                onMouseLeave={() => setProductsOpen(false)}
              >
                <a
                  className={'fiable-nav__link' + (productsOpen ? ' is-open' : '')}
                  href="#products"
                  onClick={(e) => {
                    if (window.innerWidth < 1024) {
                      e.preventDefault();
                      setProductsOpen(!productsOpen);
                    }
                  }}
                  aria-expanded={productsOpen}
                  aria-haspopup="true"
                >
                  Products
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={'fiable-nav__chevron' + (productsOpen ? ' is-up' : '')}>
                    <path d="m6 9 6 6 6-6"/>
                  </svg>
                </a>

                <div className="products-mega-menu" role="region" aria-label="Product Families Menu">
                  <div className="products-mega-menu__head">
                    <span className="products-mega-menu__eyebrow">EQUIPMENT FAMILIES</span>
                    <a className="products-mega-menu__all-link" href="#products" onClick={closeAll}>
                      Browse Full Catalogue &rarr;
                    </a>
                  </div>

                  <div className="products-mega-menu__grid">
                    {PRODUCT_FAMILIES.map((family) => (
                      <a
                        key={family.name}
                        className="mega-menu-card"
                        href="#products"
                        onClick={closeAll}
                      >
                        <div className="mega-menu-card__icon-box">
                          <img src={family.icon} alt={family.name} loading="lazy" />
                        </div>
                        <div className="mega-menu-card__body">
                          <div className="mega-menu-card__title-row">
                            <span className="mega-menu-card__title">{family.name}</span>
                            <span className="mega-menu-card__arrow" aria-hidden="true">&#8599;</span>
                          </div>
                          <p className="mega-menu-card__desc">{family.desc}</p>
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              <a className="fiable-nav__link" href="#why" onClick={closeAll}>
                Why Us
              </a>

              <a className="fiable-nav__link" href="#industries" onClick={closeAll}>
                Industries
              </a>

              <a className="fiable-nav__link" href="#certifications" onClick={closeAll}>
                Certifications
              </a>

              <a className="fiable-nav__link" href="#gallery" onClick={closeAll}>
                Gallery
              </a>

              <a className="fiable-nav__link" href="#contact" onClick={closeAll}>
                Contact
              </a>
            </nav>

            {/* Right Action Bar */}
            <div className="fiable-header__actions">
              <a className="fiable-header__phone" href={'tel:' + BUSINESS.phoneDial} aria-label={'Call ' + BUSINESS.phone}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                </svg>
                <span>{BUSINESS.phone}</span>
              </a>

              <a className="btn-request-quote" href="#contact">
                Request Quote
              </a>

              <button
                type="button"
                className={'fiable-hamburger' + (open ? ' is-active' : '')}
                aria-expanded={open}
                aria-controls="mobile-drawer"
                aria-label={open ? 'Close navigation' : 'Open navigation'}
                onClick={() => setOpen(!open)}
              >
                <span />
                <span />
                <span />
              </button>
            </div>
          </div>
        </header>
      </div>

      {/* Mobile Drawer */}
      <div id="mobile-drawer" className={'fiable-drawer' + (open ? ' is-open' : '')}>
        <div className="fiable-drawer__head">
          <span className="fiable-logo__brand">
            vikash <span className="fiable-logo__brand-sub">Traders</span>
          </span>
          <button
            type="button"
            className="fiable-drawer__close"
            onClick={() => setOpen(false)}
            aria-label="Close menu"
          >
            &times;
          </button>
        </div>

        <div className="fiable-drawer__body">
          <a className="fiable-drawer__link" href="#top" onClick={closeAll}>Home</a>
          <a className="fiable-drawer__link" href="#about" onClick={closeAll}>About Us</a>
          
          <div className="fiable-drawer__accordion">
            <span className="fiable-drawer__label">Equipment Families</span>
            <div className="fiable-drawer__sublist">
              {PRODUCT_FAMILIES.map((family) => (
                <a
                  key={family.name}
                  className="fiable-drawer__sublink"
                  href="#products"
                  onClick={closeAll}
                >
                  <span>&bull; {family.name}</span>
                </a>
              ))}
            </div>
          </div>

          <a className="fiable-drawer__link" href="#why" onClick={closeAll}>Why Us</a>
          <a className="fiable-drawer__link" href="#industries" onClick={closeAll}>Industries</a>
          <a className="fiable-drawer__link" href="#certifications" onClick={closeAll}>Certifications</a>
          <a className="fiable-drawer__link" href="#gallery" onClick={closeAll}>Gallery</a>
          <a className="fiable-drawer__link" href="#contact" onClick={closeAll}>Contact Us</a>
        </div>

        <div className="fiable-drawer__foot">
          <a className="btn-request-quote btn-request-quote--full" href="#contact" onClick={closeAll}>
            Request Quote
          </a>
          <a className="fiable-drawer__phone" href={'tel:' + BUSINESS.phoneDial}>
            Call: {BUSINESS.phone}
          </a>
        </div>
      </div>

      <div
        className={'fiable-backdrop' + (open ? ' is-active' : '')}
        onClick={closeAll}
        aria-hidden="true"
      />
    </>
  );
}
