import { BUSINESS, WHATSAPP_LINK } from '../site.js';

export default function CtaBand() {
  return (
    <section className="ctaband" aria-label="Quotation Call to Action">
      <div className="shell ctaband__inner reveal">
        <div className="ctaband__left">
          <span className="ctaband__eyebrow">&mdash; READY TO ORDER OR NEED A FORMAL QUOTE?</span>
          <h2>Tell Us What You Need &amp; We'll Prepare Your Rate Sheet</h2>
          <p>
            Direct dispatch from Lunkaransar stockyard. 100% GST tax invoices, official quotations, and verified delivery timelines.
          </p>
        </div>
        <div className="ctaband__right">
          <a className="btn btn--white" href="#contact">
            Request Formal Quote
          </a>
          <a
            className="btn btn--whatsapp-cta"
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noreferrer"
          >
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
