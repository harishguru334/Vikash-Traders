import { BUSINESS } from '../site.js';

export default function About() {
  return (
    <section className="section about-section" id="about" aria-label="About Vikash Traders">
      {/* Muted Giant Watermark Year */}
      <div className="about-watermark" aria-hidden="true">
        {BUSINESS.gstYear}
      </div>

      <div className="shell about__grid reveal">
        {/* Left Column: Story & CTAs */}
        <div className="about__content">
          <span className="section-eyebrow">&mdash; OUR STORY &mdash;</span>
          <h2 className="about__title">
            About <em>Vikash Traders</em>
          </h2>

          <p className="about__lead">
            Since {BUSINESS.gstYear}, Vikash Traders has been at the forefront of supplying premium-quality
            commercial plastic dustbins, mechanized floor cleaning machines, open-gym exercise stations, and
            construction equipment that help create cleaner, healthier and more sustainable environments across Rajasthan.
          </p>

          <p className="about__body-text">
            Based in Kankarwala, Lunkaransar (Bikaner division) under the direct leadership of proprietor
            V. Kumar, we eliminate speculative middle tiers by holding physical inventory in our central
            stockyard and dispatching verified orders directly to municipal councils, hospitals, schools and
            infrastructure contractors.
          </p>

          {/* Two Action Buttons */}
          <div className="about__actions">
            <a className="btn btn--primary" href="#products">
              Our Products Range
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 12h14m-7-7 7 7-7 7"/>
              </svg>
            </a>

            <a className="about__contact-btn" href="#contact">
              <span className="about__play-icon" aria-hidden="true">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <polygon points="5 3 19 12 5 21 5 3"/>
                </svg>
              </span>
              <div className="about__contact-btn-text">
                <strong>Contact Our Team</strong>
                <span>Get procurement assistance</span>
              </div>
            </a>
          </div>

          {/* Key Facts Pill Row */}
          <div className="about__mini-facts">
            <div className="about__mini-fact">
              <strong>Est. {BUSINESS.gstYear}</strong>
              <span>Proprietorship Active</span>
            </div>
            <div className="about__mini-fact">
              <strong>GSTIN Verified</strong>
              <span>{BUSINESS.gst}</span>
            </div>
            <div className="about__mini-fact">
              <strong>Bikaner Hub</strong>
              <span>Kankarwala Stockyard</span>
            </div>
          </div>
        </div>

        {/* Right Column: Giant Circular Cutout Image Container with Photorealistic stockyard */}
        <div className="about__visual-container">
          <div className="about__circle-mask">
            <img
              src="/photos/about-facility-stockyard.jpg"
              alt="Vikash Traders Central Facility &amp; Equipment Stockyard"
              className="about__circle-img"
            />
          </div>
          <div className="about__floating-tag">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#059669" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            <span>Swachh Bharat &amp; Municipal Standards Compliant</span>
          </div>
        </div>
      </div>
    </section>
  );
}
