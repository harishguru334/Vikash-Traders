const updates = [
  {
    tag: 'CIVIC DISPATCH',
    num: '01',
    img: '/photos/why-yellow-bin.jpg',
    date: 'OCTOBER 2026',
    title: 'Bulk Commercial Waste Bins Dispatched for Municipal Sanitation Upgrades',
    desc: 'Supply of heavy-duty 50L to 100L HDPE pedal and wheeled bins with Swachh Bharat color-coding and full GST audit paperwork.',
  },
  {
    tag: 'COMMERCIAL HANDOVER',
    num: '02',
    img: '/photos/fiable-hero-equipment.jpg',
    date: 'SEPTEMBER 2026',
    title: 'Mechanized Floor Scrubbers & Wet/Dry Vacuums Deployed to Commercial Complexes',
    desc: 'Industrial cleaning machines dispatched to facilities in Bikaner and surrounding districts for large-area mechanized floor care.',
  },
  {
    tag: 'PUBLIC INFRASTRUCTURE',
    num: '03',
    img: '/photos/about-facility-stockyard.jpg',
    date: 'AUGUST 2026',
    title: 'Outdoor Gym Exercise Stations Delivered to Public Parks & Gram Panchayats',
    desc: 'Installed all-weather air walkers, waist twisters and pull-down stations designed for open civic community parks.',
  },
];

export default function Newsroom() {
  return (
    <section className="section newsroom-section" id="newsroom" aria-label="Operations & Newsroom">
      <div className="shell">
        <div className="section-head reveal">
          <span className="section-eyebrow">&mdash; DISPATCH DISPATCHES &amp; UPDATES &mdash;</span>
          <h2>Latest News &amp; <em>Field Deployments</em></h2>
          <p>
            Stay updated with recent equipment dispatches, institutional supplies, and civic sanitation installations across Rajasthan.
          </p>
        </div>

        <div className="newsroom-grid reveal">
          {updates.map((item) => (
            <article className="news-card" key={item.num}>
              <div className="news-card__thumb">
                <img src={item.img} alt={item.title} loading="lazy" />
                <span className="news-card__num">{item.num}</span>
                <span className="news-card__tag">{item.tag}</span>
              </div>
              <div className="news-card__body">
                <div className="news-card__date">{item.date}</div>
                <h3 className="news-card__title">{item.title}</h3>
                <p className="news-card__desc">{item.desc}</p>
                <a className="news-card__link" href="#contact">
                  Enquire about similar supply &rarr;
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
