import { BUSINESS, NAV, CORE_CATEGORIES } from '../site.js';

export default function Footer({ products = [] }) {
  const categories = products.length > 0
    ? Array.from(new Set(products.map((p) => p.category)))
    : CORE_CATEGORIES;

  return (
    <footer className="fiable-footer" aria-label="Site Footer">
      <div className="shell">
        <div className="fiable-footer__grid">
          {/* Column 1: Brand Info */}
          <div className="fiable-footer__brand-col">
            <a className="fiable-footer__logo" href="#top" aria-label="Vikash Traders Home">
              <span className="fiable-footer__logo-mark" aria-hidden="true">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L3 7v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-9-5z" fill="#059669"/>
                  <path d="M9.5 12l2 2 3.5-3.5" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </span>
              <span className="fiable-footer__brand-name">
                vikash <span>Traders</span>
              </span>
            </a>
            <p className="fiable-footer__tagline">
              Direct supplier and stockyard of commercial cleaning machines, plastic dustbins, open-gym stations, queue stanchions, and construction machinery across Rajasthan.
            </p>
            <div className="fiable-footer__gst-pill">
              <span className="fiable-footer__gst-dot" aria-hidden="true" />
              GSTIN: {BUSINESS.gst} &middot; Active Since {BUSINESS.gstYear}
            </div>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="fiable-footer__col">
            <h4 className="fiable-footer__title">Quick Navigation</h4>
            <ul className="fiable-footer__links">
              {NAV.map((link) => (
                <li key={link.label}>
                  <a href={link.href}>{link.label}</a>
                </li>
              ))}
              <li><a href="#certifications">Certifications</a></li>
              <li><a href="#newsroom">News &amp; Field Updates</a></li>
            </ul>
          </div>

          {/* Column 3: Equipment Categories */}
          <div className="fiable-footer__col">
            <h4 className="fiable-footer__title">Core Equipment</h4>
            <ul className="fiable-footer__links">
              {categories.map((c) => (
                <li key={c}>
                  <a href="#products">{c}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Facility & Contact */}
          <div className="fiable-footer__col">
            <h4 className="fiable-footer__title">Stockyard Facility</h4>
            <address className="fiable-footer__address">
              <p><strong>Vikash Traders</strong></p>
              <p>Proprietor: {BUSINESS.proprietor}</p>
              <p>{BUSINESS.address}</p>
              <p>Hours: {BUSINESS.hours}</p>
              <p>Phone: <a href={'tel:' + BUSINESS.phoneDial}>{BUSINESS.phone}</a></p>
            </address>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="fiable-footer__bottom">
          <p className="fiable-footer__copy">
            &copy; {new Date().getFullYear()} {BUSINESS.name}. All rights reserved. GST Registered Proprietorship.
          </p>
          <div className="fiable-footer__bottom-links">
            <a href="#top">Back to Top &uarr;</a>
            <a href="/admin/login">Admin Access</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
