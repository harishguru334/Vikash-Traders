import { useMemo, useState } from 'react';
import { rupees } from '../site.js';
import { assetUrl } from '../api/client.js';

export default function Products({ products, loading, error, onEnquire }) {
  const [active, setActive] = useState('All');

  const categories = useMemo(() => {
    const seen = [];
    products.forEach((p) => {
      if (!seen.includes(p.category)) seen.push(p.category);
    });
    return seen;
  }, [products]);

  const shown = active === 'All' ? categories : categories.filter((c) => c === active);

  return (
    <section className="section" id="products" aria-label="Commercial Equipment Catalogue">
      <div className="shell">
        <span className="section-eyebrow">&mdash; COMMERCIAL CATALOGUE &mdash;</span>
        <div className="section-head reveal">
          <h2>Engineered Equipment &amp; <em>Verified Wholesale Rates</em></h2>
          <p>
            Prices are per piece and exclude GST. Figures below reflect the active catalogue in our system.
            Dispatched directly from our Lunkaransar facility.
          </p>
        </div>

        {loading && (
          <div className="state-box flex flex-col items-center justify-center p-12 bg-white rounded-2xl border border-slate-200 shadow-sm">
            <span className="w-10 h-10 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin mb-4" aria-hidden="true" />
            <p className="font-semibold text-slate-700">Loading commercial equipment catalogue&hellip;</p>
          </div>
        )}

        {error && (
          <div className="p-6 bg-red-50 border border-red-200 rounded-2xl text-red-700 font-medium">
            <p>{error}</p>
          </div>
        )}

        {!loading && !error && products.length === 0 && (
          <div className="p-8 bg-white rounded-2xl border border-slate-200 text-center text-slate-600">
            <p>No products are currently published in the catalogue. Call us for live rates.</p>
          </div>
        )}

        {products.length > 0 && (
          <>
            {/* Filter Pills with Spring Animation Hover */}
            <div className="filters reveal" role="tablist" aria-label="Product Category Filters">
              <button
                className={'filter' + (active === 'All' ? ' filter--on' : '')}
                onClick={() => setActive('All')}
                role="tab"
                aria-selected={active === 'All'}
              >
                All Categories ({products.length})
              </button>
              {categories.map((c) => {
                const count = products.filter((p) => p.category === c).length;
                return (
                  <button
                    key={c}
                    className={'filter' + (active === c ? ' filter--on' : '')}
                    onClick={() => setActive(c)}
                    role="tab"
                    aria-selected={active === c}
                  >
                    {c} ({count})
                  </button>
                );
              })}
            </div>

            {/* Product Category Blocks */}
            {shown.map((category) => {
              const items = products.filter((p) => p.category === category);
              const prices = items.map((p) => p.price);
              const low = Math.min(...prices);
              const high = Math.max(...prices);

              return (
                <div className="cat-block reveal" key={category}>
                  <div className="cat-block__head">
                    <div>
                      <h3 className="cat-block__title">{category}</h3>
                      <span className="cat-block__count">{items.length} {items.length === 1 ? 'Model' : 'Models'} Available</span>
                    </div>
                    <span className="cat-block__range">
                      {low === high ? rupees(low) : rupees(low) + ' – ' + rupees(high)}
                    </span>
                  </div>

                  <div className="products">
                    {items.map((p) => (
                      <article className="product group" key={p._id}>
                        <div className="product__img overflow-hidden">
                          {p.imageUrl ? (
                            <img src={assetUrl(p.imageUrl)} alt={p.name} loading="lazy" className="transition-transform duration-500 group-hover:scale-108" />
                          ) : (
                            <div className="product__fallback">
                              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
                                <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                              </svg>
                              <span>Stock Available &middot; Photo on Request</span>
                            </div>
                          )}
                          <span className="product__category-tag">{p.category}</span>
                        </div>
                        <div className="product__body">
                          <h4 className="product__name group-hover:text-emerald-700 transition-colors duration-200">{p.name}</h4>
                          <div className="product__pricing">
                            <div className="product__price">{rupees(p.price)}</div>
                            <div className="product__unit">per piece, excl. GST</div>
                          </div>
                          <button
                            className="btn btn--primary btn--full product__cta group/btn"
                            onClick={() => onEnquire(p.name)}
                          >
                            <span>Ask for this Rate</span>
                            <span className="transform group-hover/btn:translate-x-1.5 transition-transform duration-200">&rarr;</span>
                          </button>
                        </div>
                      </article>
                    ))}
                  </div>
                </div>
              );
            })}
          </>
        )}
      </div>
    </section>
  );
}
