import { BUSINESS } from '../site.js';

const certificates = [
  {
    id: 'cert-gst',
    iconType: 'tax',
    authority: 'Government of India · Commercial Taxes Dept, Rajasthan',
    title: 'GST Statutory Registration',
    regNo: BUSINESS.gst,
    issuedDate: 'Active Since ' + BUSINESS.gstYear,
    scope: 'Trading & supply of plastic dustbins, cleaning machines, outdoor gym stations, queue barriers & construction equipment.',
    badge: 'Verified Active on GST Portal',
    badgeColor: 'green',
  },
  {
    id: 'cert-iso',
    iconType: 'shield',
    authority: 'Quality Management Standards Alignment',
    title: 'ISO 9001:2015 Quality Aligned Supply',
    regNo: 'ISO 9001:2015 & ISO 14001',
    issuedDate: 'Manufacturing Partner Standards',
    scope: 'Commercial grade equipment sourced from vetted ISO certified production lines with strict multi-point pre-dispatch inspections.',
    badge: 'Industrial Quality Standard',
    badgeColor: 'blue',
  },
  {
    id: 'cert-en840',
    iconType: 'container',
    authority: 'European & Indian Municipal Standards',
    title: 'EN 840 & IS Standard Compliance',
    regNo: 'EN 840-1 to 840-6 · IS 12402',
    issuedDate: '100% Virgin High-Density HDPE',
    scope: 'Heavy-duty wheeled commercial dustbins injection moulded from virgin HDPE, UV-stabilized against extreme heat and outdoor weathering.',
    badge: 'Municipal Tender Compliant',
    badgeColor: 'emerald',
  },
  {
    id: 'cert-msme',
    iconType: 'building',
    authority: 'Ministry of Micro, Small & Medium Enterprises',
    title: 'MSME / Udyam Enterprise Registered',
    regNo: 'Udyam Registration Verified',
    issuedDate: 'Bikaner Division, Rajasthan',
    scope: 'Recognized government procurement supplier for public infrastructure, civic hygiene equipment and municipal installations.',
    badge: 'Govt. Recognized Enterprise',
    badgeColor: 'amber',
  },
];

const pillars = [
  {
    number: '01',
    title: 'Statutory Legitimacy',
    desc: 'Every transaction is accompanied by GST tax invoices, clear HSN classifications, and transport e-Way bills.',
  },
  {
    number: '02',
    title: 'Material Integrity',
    desc: 'Heavy-gauge steel tubing for gym stations, certified high-density virgin polymers for bins, and copper motors for machines.',
  },
  {
    number: '03',
    title: 'Direct Dispatch',
    desc: 'Dispatch directly from our central Lunkaransar stockyard with same-day confirmation for in-stock equipment.',
  },
  {
    number: '04',
    title: 'Procurement Support',
    desc: 'Detailed specification sheets, tender documentation assistance, and prompt quote responses.',
  },
];

function CertIcon({ type }) {
  if (type === 'tax') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="5" width="20" height="14" rx="2"/>
        <line x1="2" y1="10" x2="22" y2="10"/>
      </svg>
    );
  }
  if (type === 'shield') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <polyline points="9 12 11 14 15 10"/>
      </svg>
    );
  }
  if (type === 'container') {
    return (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 6h18"/>
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
      </svg>
    );
  }
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="2" width="16" height="20" rx="2"/>
      <line x1="9" y1="22" x2="9" y2="2"/>
      <line x1="8" y1="6" x2="8.01" y2="6"/>
      <line x1="16" y1="6" x2="16.01" y2="6"/>
    </svg>
  );
}

export default function Certifications() {
  return (
    <section className="section cert-section" id="certifications" aria-label="Certifications and Quality Standards">
      <div className="shell">
        <div className="section-head reveal">
          <span className="section-eyebrow">&mdash; COMPLIANCE &amp; STANDARDS &mdash;</span>
          <h2>Verified Credentials &amp; <em>Quality Standards</em></h2>
          <p>
            Vikash Traders operates with 100% statutory transparency and adheres to stringent national and international
            manufacturing standards for civic equipment.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="cert-grid reveal">
          {certificates.map((cert) => (
            <div className={'cert-card cert-card--' + cert.badgeColor} key={cert.id}>
              <div className="cert-card__top">
                <div className="cert-card__icon-wrap">
                  <CertIcon type={cert.iconType} />
                </div>
                <span className={'cert-card__badge cert-card__badge--' + cert.badgeColor}>
                  {cert.badge}
                </span>
              </div>

              <div className="cert-card__authority">{cert.authority}</div>
              <h3 className="cert-card__title">{cert.title}</h3>

              <div className="cert-card__reg">
                <span className="cert-card__reg-label">Identifier / Standard:</span>
                <span className="cert-card__reg-val">{cert.regNo}</span>
              </div>

              <div className="cert-card__date">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <circle cx="12" cy="12" r="10"/>
                  <polyline points="12 6 12 12 16 14"/>
                </svg>
                {cert.issuedDate}
              </div>

              <p className="cert-card__scope">{cert.scope}</p>
            </div>
          ))}
        </div>

        {/* 4 Pillars Strip */}
        <div className="cert-pillars reveal">
          <div className="cert-pillars__title">
            <span>Our Quality Commitments</span>
            <p>Non-negotiable benchmarks on every order dispatched from our facility.</p>
          </div>
          <div className="cert-pillars__grid">
            {pillars.map((pillar) => (
              <div className="cert-pillar" key={pillar.number}>
                <span className="cert-pillar__num">{pillar.number}</span>
                <h4 className="cert-pillar__name">{pillar.title}</h4>
                <p className="cert-pillar__desc">{pillar.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
