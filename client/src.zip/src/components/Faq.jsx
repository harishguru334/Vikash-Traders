import { useState } from 'react';

const faqs = [
  {
    q: 'Where do you deliver?',
    a: 'Across Rajasthan. Orders in Bikaner division usually go out within the same week; other districts are dispatched by road transport, and the freight cost is shown in your quote before you confirm.',
  },
  {
    q: 'Do you provide a GST invoice?',
    a: 'Yes. Vikash Traders has been GST registered since 2022 under 08LLOPK9460L1Z0, and every order is billed with a proper tax invoice suitable for institutional and government buyers.',
  },
  {
    q: 'Are the listed prices negotiable for bulk orders?',
    a: 'The prices on this site are per-piece rates. For quantities — a full set of park equipment, or bins by the hundred — send your requirement and we will quote a bulk rate against it.',
  },
  {
    q: 'How quickly will I get a quote?',
    a: 'Enquiries received during business hours, Monday to Saturday between 9 AM and 7 PM, are quoted the same day. Anything that arrives after hours is answered the next working morning.',
  },
  {
    q: 'Can you supply against a government tender or purchase order?',
    a: 'Yes. Share the tender specification or purchase order and we will respond with item-wise rates, delivery timelines and the documentation you need.',
  },
];

export default function Faq() {
  const [open, setOpen] = useState(0);

  return (
    <section className="section">
      <div className="shell reveal">
        <div className="section-head">
          <h2>Questions buyers ask first</h2>
        </div>
        <div className="faq">
          {faqs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div className="faq__item" key={item.q}>
                <h3 style={{ margin: 0 }}>
                  <button
                    className="faq__q"
                    aria-expanded={isOpen}
                    aria-controls={`faq-a-${i}`}
                    onClick={() => setOpen(isOpen ? -1 : i)}
                  >
                    {item.q}
                    <span className="faq__sign" aria-hidden="true">{isOpen ? '–' : '+'}</span>
                  </button>
                </h3>
                <div id={`faq-a-${i}`} className={`faq__a${isOpen ? ' faq__a--open' : ''}`}>
                  <p>{item.a}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
