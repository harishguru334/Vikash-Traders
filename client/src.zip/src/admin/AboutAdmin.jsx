import { useEffect, useState } from 'react';
import api, { apiError } from '../api/client.js';

export default function AboutAdmin() {
  const [data, setData] = useState({
    heading: '',
    intro: '',
    description: '',
    highlights: [],
    image: 'assets/hero-equipment-showcase.svg',
  });
  const [statusText, setStatusText] = useState('Published');
  const [highlightsInput, setHighlightsInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState({ type: null, text: '' });

  useEffect(() => {
    async function fetchAbout() {
      try {
        const res = await api.get('/admin/content/about');
        if (res.data && Object.keys(res.data).length > 0) {
          setData(res.data);
          setHighlightsInput((res.data.highlights || []).join('\n'));
        }
      } catch (err) {
        setFeedback({ type: 'err', text: apiError(err, 'Failed to load About Us content.') });
      } finally {
        setLoading(false);
      }
    }
    fetchAbout();
  }, []);

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setFeedback({ type: null, text: '' });

    const highlights = highlightsInput
      .split('\n')
      .map(h => h.trim())
      .filter(Boolean);

    const payload = {
      ...data,
      highlights,
    };

    try {
      await api.post('/admin/content/about', { data: payload, status: statusText });
      setFeedback({ type: 'ok', text: 'About Us section saved & synced to live website successfully.' });
    } catch (err) {
      setFeedback({ type: 'err', text: apiError(err, 'Failed to save About Us content.') });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <p className="admin-boot">Loading About Us editor…</p>;

  return (
    <div className="admin-page">
      <header className="admin__head" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1>About Us Content Editor</h1>
          <p>Verified factual company information. Updates appear instantly on the public website About section.</p>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className={`pill ${statusText === 'Published' ? 'pill--active' : 'pill--draft'}`}>
            {statusText}
          </span>
          <button 
            type="button" 
            className="btn btn--ghost btn--sm" 
            onClick={() => setStatusText(s => s === 'Published' ? 'Draft' : 'Published')}
          >
            {statusText === 'Published' ? 'Set as Draft' : 'Set as Published'}
          </button>
          <button type="button" className="btn btn--primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving…' : 'Save & Publish'}
          </button>
        </div>
      </header>

      {feedback.text && (
        <div className={`formmsg formmsg--${feedback.type}`} style={{ marginBottom: 16 }}>
          {feedback.text}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: 20 }}>
        {/* Editor Form */}
        <div className="panel" style={{ padding: 24 }}>
          <div className="form-group">
            <label>Section Heading *</label>
            <input 
              type="text" 
              className="input" 
              value={data.heading} 
              onChange={(e) => setData({ ...data, heading: e.target.value })} 
              placeholder="e.g. Direct B2B Industrial Equipment Sourcing Without Middlemen"
              required 
            />
          </div>

          <div className="form-group">
            <label>Company Introduction *</label>
            <textarea 
              className="textarea" 
              rows="3" 
              value={data.intro} 
              onChange={(e) => setData({ ...data, intro: e.target.value })} 
              placeholder="High-level commercial intro of Vikash Traders..." 
              required 
            />
          </div>

          <div className="form-group">
            <label>Full Procurement & Sourcing Description *</label>
            <textarea 
              className="textarea" 
              rows="5" 
              value={data.description} 
              onChange={(e) => setData({ ...data, description: e.target.value })} 
              placeholder="Details on factory lines, verified quality benchmarks, logistics..." 
              required 
            />
          </div>

          <div className="form-group">
            <label>Key Value Highlights (One per line)</label>
            <textarea 
              className="textarea" 
              rows="4" 
              value={highlightsInput} 
              onChange={(e) => setHighlightsInput(e.target.value)} 
              placeholder="100% Tax Invoiced with official GSTIN&#10;Factory-direct wholesale rates&#10;Field-tested commercial specifications" 
            />
            <span style={{ fontSize: '0.78rem', color: '#64748b' }}>Separate each highlight bullet by pressing Enter.</span>
          </div>

          <div className="form-group">
            <label>Section Image Asset Path</label>
            <input 
              type="text" 
              className="input" 
              value={data.image} 
              onChange={(e) => setData({ ...data, image: e.target.value })} 
              placeholder="assets/hero-equipment-showcase.svg" 
            />
          </div>
        </div>

        {/* Live Preview Card */}
        <div>
          <div className="panel" style={{ padding: 20 }}>
            <span style={{ fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.06em', color: '#64748b', textTransform: 'uppercase' }}>
              Live Website Preview
            </span>
            <div style={{ marginTop: 12, borderTop: '1px solid #e2e8f0', paddingTop: 12 }}>
              <h3 style={{ fontSize: '1.15rem', color: '#0f172a', marginBottom: 8, lineHeight: 1.3 }}>
                {data.heading || 'Direct B2B Industrial Equipment Sourcing'}
              </h3>
              <p style={{ fontSize: '0.85rem', color: '#0c5e42', fontWeight: 600, marginBottom: 12 }}>
                {data.intro || 'Intro summary...'}
              </p>
              <p style={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.5, marginBottom: 16 }}>
                {data.description || 'Full description...'}
              </p>

              <div style={{ background: '#f8fafc', padding: 12, borderRadius: 6, marginBottom: 16 }}>
                <strong style={{ fontSize: '0.78rem', color: '#1e293b', display: 'block', marginBottom: 6 }}>Key Assurances:</strong>
                <ul style={{ margin: 0, paddingLeft: 18, fontSize: '0.8rem', color: '#334155' }}>
                  {highlightsInput.split('\n').filter(Boolean).map((h, i) => (
                    <li key={i} style={{ marginBottom: 4 }}>{h}</li>
                  ))}
                </ul>
              </div>

              {data.image && (
                <div style={{ textAlign: 'center', background: '#f1f5f9', padding: 12, borderRadius: 6 }}>
                  <img src={data.image} alt="Preview" style={{ maxHeight: 140, maxWidth: '100%', objectFit: 'contain' }} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
